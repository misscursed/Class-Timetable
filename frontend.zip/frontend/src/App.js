import React, { useState } from 'react';
import axios from 'axios';
import Cookies from 'js-cookie';
import { Tabs, TabList, Tab, TabPanel } from 'react-tabs';
import 'react-tabs/style/react-tabs.css';
import './App.css';

function App() {
  const [file, setFile] = useState(null);
  const [timetable, setTimetable] = useState(null);
  const [error, setError] = useState('');

  const handleFileChange = (e) => {
    setFile(e.target.files[0]);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!file) {
      setError('Please upload a file');
      return;
    }

    const formData = new FormData();
    formData.append('file', file);

    // Get CSRF token from cookie
    const csrftoken = Cookies.get('csrftoken');

    try {
      const response = await axios.post('http://127.0.0.1:8000/upload/', formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
          'X-CSRFToken': csrftoken, // Send CSRF token
        },
      });
      setTimetable(response.data.timetable);
      setError('');
    } catch (err) {
      setError('Error generating timetable');
      console.error(err);
    }
  };

  const renderTimetable = (yearData) => {
    if (!yearData || yearData.length === 0) return <p>No data for this year</p>;

    const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];
    const hours = Array.from({ length: 10 }, (_, i) => 9 + i); // 9 AM to 6 PM

    return (
      <table className="timetable-table">
        <thead>
          <tr>
            <th>Time</th>
            {days.map((day) => (
              <th key={day}>{day}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {hours.map((hour) => (
            <tr key={hour}>
              <td>{`${hour}:00 - ${hour + 1}:00`}</td>
              {days.map((day) => {
                const slot = yearData.find(
                  (entry) => entry.day === day && entry.start === hour
                );
                return (
                  <td key={day}>
                    {slot ? `${slot.subject} (${slot.teacher}) - ${slot.venue}` : '-'}
                  </td>
                );
              })}
            </tr>
          ))}
        </tbody>
      </table>
    );
  };

  return (
    <div className="App">
      <h1>Timetable Generator</h1>
      <form onSubmit={handleSubmit}>
        <input type="file" onChange={handleFileChange} />
        <button type="submit">Generate Timetable</button>
      </form>
      {error && <p className="error">{error}</p>}
      {timetable && (
        <Tabs>
          <TabList>
            {Object.keys(timetable).map((year) => (
              <Tab key={year}>{year}</Tab>
            ))}
          </TabList>
          {Object.entries(timetable).map(([year, data]) => (
            <TabPanel key={year}>
              <h2>{year} Timetable</h2>
              {renderTimetable(data)}
            </TabPanel>
          ))}
        </Tabs>
      )}
    </div>
  );
}

export default App;