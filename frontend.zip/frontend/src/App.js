



// import React, { useState, useEffect } from 'react';

// // Function to get CSRF token from cookie
// const getCsrfToken = () => {
//   const name = 'csrftoken';
//   const cookies = document.cookie.split(';');
//   for (let cookie of cookies) {
//     cookie = cookie.trim();
//     if (cookie.startsWith(name + '=')) {
//       return cookie.substring(name.length + 1);
//     }
//   }
//   return '';
// };

// function App() {
//   const [fileInput, setFileInput] = useState(null);
//   const [excelFile, setExcelFile] = useState(null);
//   const [subjectTeacherPairs, setSubjectTeacherPairs] = useState([]);
//   const [selectedSubject, setSelectedSubject] = useState('');
//   const [hours, setHours] = useState('');
//   const [year, setYear] = useState('1st Year');
//   const [scheduleType, setScheduleType] = useState('distributed'); // New state for schedule type
//   const [subjectsList, setSubjectsList] = useState([]);
//   const [timetables, setTimetables] = useState([]);
//   const [selectedTimetable, setSelectedTimetable] = useState('');
//   const [errorMessage, setErrorMessage] = useState('');

//   useEffect(() => {
//     console.log('App component mounted');
//     const fetchSubjectTeacherPairs = async () => {
//       try {
//         const response = await fetch('/api/', {
//           method: 'GET',
//           headers: { 'Content-Type': 'application/json' },
//         });
//         console.log('GET response status:', response.status);
//         console.log('GET response headers:', response.headers.get('content-type'));
//         const data = await response.json();
//         console.log('Initial GET response:', data);
//         setSubjectTeacherPairs(data.subject_teacher_pairs || []);
//       } catch (error) {
//         console.error('Error fetching subject-teacher pairs:', error);
//       }
//     };
//     fetchSubjectTeacherPairs();
//   }, []);

//   const handleFileChange = (e) => {
//     const selectedFile = e.target.files[0];
//     console.log('File selected:', selectedFile ? selectedFile.name : 'No file');
//     setFileInput(selectedFile);
//     setExcelFile(selectedFile);
//   };

//   const handleFileUpload = async (e) => {
//     e.preventDefault();
//     console.log('Form submitted');
//     if (!fileInput) {
//       console.log('No file selected for upload');
//       setErrorMessage('Please select a file to upload.');
//       return;
//     }

//     const formData = new FormData();
//     formData.append('excelFile', fileInput);
//     console.log('Uploading file:', fileInput.name);

//     try {
//       const response = await fetch('/api/', {
//         method: 'POST',
//         headers: {
//           'X-CSRFToken': getCsrfToken(),
//         },
//         body: formData,
//       });
//       console.log('POST response status:', response.status);
//       console.log('POST response headers:', response.headers.get('content-type'));
//       const data = await response.json();
//       console.log('File upload response:', data);
//       if (data.subject_teacher_pairs) {
//         setSubjectTeacherPairs(data.subject_teacher_pairs);
//         setErrorMessage('');
//       }
//     } catch (error) {
//       console.error('Error uploading file:', error);
//       setErrorMessage('Failed to upload file. Please try again.');
//     }
//   };

//   const handleAddSubject = () => {
//     if (selectedSubject && hours && year) {
//       const newSubject = { subject_teacher: selectedSubject, hours, year, schedule_type: scheduleType };
//       setSubjectsList([...subjectsList, newSubject]);
//       console.log('Added subject:', newSubject);
//       console.log('Current subjects list:', [...subjectsList, newSubject]);
//       setSelectedSubject('');
//       setHours('');
//     } else {
//       console.log('Cannot add subject: missing fields', { selectedSubject, hours, year });
//     }
//   };

//   const handleGenerateTimetables = async () => {
//     console.log('Generate Timetables button clicked');
//     console.log('Subjects list to send:', subjectsList);
//     if (!subjectsList.length) {
//       console.log('No subjects to generate timetable for');
//       setErrorMessage('Please add at least one subject.');
//       return;
//     }

//     if (!excelFile) {
//       console.log('No Excel file available for timetable generation');
//       setErrorMessage('Please upload the Excel file again before generating timetables.');
//       return;
//     }

//     const formData = new FormData();
//     formData.append('subjects_list', JSON.stringify(subjectsList));
//     formData.append('excelFile', excelFile);
//     console.log('Excel file included in timetable generation request:', excelFile.name);

//     try {
//       const response = await fetch('/api/', {
//         method: 'POST',
//         headers: {
//           'X-CSRFToken': getCsrfToken(),
//         },
//         body: formData,
//       });
//       console.log('POST response status:', response.status);
//       console.log('POST response headers:', response.headers.get('content-type'));
//       const data = await response.json();
//       console.log('Timetables response:', data);
//       if (data.timetables) {
//         console.log('Setting timetables:', data.timetables);
//         setTimetables(data.timetables);
//         setSelectedTimetable('');
//         setErrorMessage('');
//       } else {
//         console.log('No timetables in response:', data);
//         setErrorMessage('No timetables generated. Check the input data.');
//       }
//     } catch (error) {
//       console.error('Error generating timetables:', error);
//       setErrorMessage('Failed to generate timetables. Please try again.');
//     }
//   };

//   // Define time slots from 8 AM to 6 PM
//   const timeSlots = [];
//   for (let hour = 8; hour < 18; hour++) {
//     timeSlots.push(`${hour}-${hour + 1}`);
//   }

//   const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];

//   // Function to find lecture for a specific time slot and day
//   const getLectureForSlot = (timetable, day, startHour) => {
//     const slot = timetable.find(
//       (entry) =>
//         entry.day === day &&
//         entry.start_hour <= startHour &&
//         entry.end_hour > startHour
//     );
//     return slot ? `${slot.subject}, ${slot.venue}` : '';
//   };

//   return (
//     <div className="container">
//       <h1>Timetable Generator</h1>

//       {errorMessage && (
//         <div className="error-message" style={{ color: 'red', marginBottom: '10px' }}>
//           {errorMessage}
//         </div>
//       )}

//       <form onSubmit={handleFileUpload}>
//         <input
//           type="file"
//           accept=".xlsx"
//           onChange={handleFileChange}
//         />
//         <button type="submit" className="btn-blue">Upload</button>
//       </form>

//       <div>
//         <select
//           className="select"
//           value={selectedSubject}
//           onChange={(e) => setSelectedSubject(e.target.value)}
//         >
//           <option value="">Select Subject-Teacher</option>
//           {subjectTeacherPairs.map((pair, index) => (
//             <option key={index} value={pair}>{pair}</option>
//           ))}
//         </select>
//         <input
//           type="number"
//           placeholder="Hours per week"
//           value={hours}
//           onChange={(e) => setHours(e.target.value)}
//         />
//         <select
//           className="select"
//           value={year}
//           onChange={(e) => setYear(e.target.value)}
//         >
//           <option value="1st Year">1st Year</option>
//           <option value="2nd Year">2nd Year</option>
//           <option value="3rd Year">3rd Year</option>
//           <option value="4th Year">4th Year</option>
//         </select>
//         <select
//           className="select"
//           value={scheduleType}
//           onChange={(e) => setScheduleType(e.target.value)}
//         >
//           <option value="distributed">Distributed Across Days</option>
//           <option value="all_together">All Together</option>
//         </select>
//         <button className="btn-blue" onClick={handleAddSubject}>Add Subject</button>
//       </div>

//       <div>
//         <h2>Selected Subjects</h2>
//         <ul>
//           {subjectsList.map((subject, index) => (
//             <li key={index}>
//               {subject.subject_teacher} - {subject.hours} hours - {subject.year} - {subject.schedule_type}
//             </li>
//           ))}
//         </ul>
//       </div>

//       <button className="btn-green" onClick={handleGenerateTimetables}>
//         Generate Timetables
//       </button>

//       {timetables.length > 0 && (
//         <div>
//           <h2>Generated Timetables</h2>
//           <select
//             className="select"
//             value={selectedTimetable}
//             onChange={(e) => setSelectedTimetable(e.target.value)}
//           >
//             <option value="">Select Timetable</option>
//             {timetables.map((_, index) => (
//               <option key={index} value={index}>Timetable {index + 1}</option>
//             ))}
//           </select>

//           {selectedTimetable !== '' && (
//             <table className="table">
//               <thead>
//                 <tr>
//                   <th>Time</th>
//                   {days.map((day) => (
//                     <th key={day}>{day}</th>
//                   ))}
//                 </tr>
//               </thead>
//               <tbody>
//                 {timeSlots.map((slot, index) => {
//                   const startHour = parseInt(slot.split('-')[0]);
//                   return (
//                     <tr key={index}>
//                       <td>{slot}</td>
//                       {days.map((day) => (
//                         <td key={day}>
//                           {getLectureForSlot(timetables[selectedTimetable], day, startHour)}
//                         </td>
//                       ))}
//                     </tr>
//                   );
//                 })}
//               </tbody>
//             </table>
//           )}
//         </div>
//       )}
//     </div>
//   );
// }

// export default App;






import React, { useState, useEffect } from 'react';

// Function to get CSRF token from cookie
const getCsrfToken = () => {
  const name = 'csrftoken';
  const cookies = document.cookie.split(';');
  for (let cookie of cookies) {
    cookie = cookie.trim();
    if (cookie.startsWith(name + '=')) {
      return cookie.substring(name.length + 1);
    }
  }
  return '';
};

function App() {
  const [fileInput, setFileInput] = useState(null);
  const [excelFile, setExcelFile] = useState(null);
  const [subjectTeacherPairs, setSubjectTeacherPairs] = useState([]);
  const [fullPairs, setFullPairs] = useState([]); // Store full subject-teacher pairs
  const [selectedSubject, setSelectedSubject] = useState('');
  const [hours, setHours] = useState('');
  const [year, setYear] = useState('1st Year');
  const [scheduleType, setScheduleType] = useState('distributed');
  const [subjectsList, setSubjectsList] = useState([]);
  const [timetables, setTimetables] = useState([]);
  const [selectedTimetable, setSelectedTimetable] = useState('');
  const [errorMessage, setErrorMessage] = useState('');

  useEffect(() => {
    console.log('App component mounted');
    const fetchSubjectTeacherPairs = async () => {
      try {
        const response = await fetch('/api/', {
          method: 'GET',
          headers: { 'Content-Type': 'application/json' },
        });
        console.log('GET response status:', response.status);
        console.log('GET response headers:', response.headers.get('content-type'));
        const data = await response.json();
        console.log('Initial GET response:', data);
        setSubjectTeacherPairs(data.subject_teacher_pairs || []);
      } catch (error) {
        console.error('Error fetching subject-teacher pairs:', error);
      }
    };
    fetchSubjectTeacherPairs();
  }, []);

  const handleFileChange = (e) => {
    const selectedFile = e.target.files[0];
    console.log('File selected:', selectedFile ? selectedFile.name : 'No file');
    setFileInput(selectedFile);
    setExcelFile(selectedFile);
  };

  const handleFileUpload = async (e) => {
    e.preventDefault();
    console.log('Form submitted');
    if (!fileInput) {
      console.log('No file selected for upload');
      setErrorMessage('Please select a file to upload.');
      return;
    }

    const formData = new FormData();
    formData.append('excelFile', fileInput);
    console.log('Uploading file:', fileInput.name);

    try {
      const response = await fetch('/api/', {
        method: 'POST',
        headers: {
          'X-CSRFToken': getCsrfToken(),
        },
        body: formData,
      });
      console.log('POST response status:', response.status);
      console.log('POST response headers:', response.headers.get('content-type'));
      const data = await response.json();
      console.log('File upload response:', data);
      if (data.subject_teacher_pairs) {
        setSubjectTeacherPairs(data.subject_teacher_pairs);
        setFullPairs(data.full_pairs || []); // Store full pairs
        setErrorMessage('');
      }
    } catch (error) {
      console.error('Error uploading file:', error);
      setErrorMessage('Failed to upload file. Please try again.');
    }
  };

  const handleAddSubject = () => {
    if (selectedSubject && hours && year) {
      // Find the full subject-teacher pair based on the selected subject
      const index = subjectTeacherPairs.indexOf(selectedSubject);
      const fullSubjectTeacher = fullPairs[index] || selectedSubject;
      const newSubject = { subject_teacher: fullSubjectTeacher, hours, year, schedule_type: scheduleType };
      setSubjectsList([...subjectsList, newSubject]);
      console.log('Added subject:', newSubject);
      console.log('Current subjects list:', [...subjectsList, newSubject]);
      setSelectedSubject('');
      setHours('');
    } else {
      console.log('Cannot add subject: missing fields', { selectedSubject, hours, year });
    }
  };

  const handleGenerateTimetables = async () => {
    console.log('Generate Timetables button clicked');
    console.log('Subjects list to send:', subjectsList);
    if (!subjectsList.length) {
      console.log('No subjects to generate timetable for');
      setErrorMessage('Please add at least one subject.');
      return;
    }

    if (!excelFile) {
      console.log('No Excel file available for timetable generation');
      setErrorMessage('Please upload the Excel file again before generating timetables.');
      return;
    }

    const formData = new FormData();
    formData.append('subjects_list', JSON.stringify(subjectsList));
    formData.append('excelFile', excelFile);
    console.log('Excel file included in timetable generation request:', excelFile.name);

    try {
      const response = await fetch('/api/', {
        method: 'POST',
        headers: {
          'X-CSRFToken': getCsrfToken(),
        },
        body: formData,
      });
      console.log('POST response status:', response.status);
      console.log('POST response headers:', response.headers.get('content-type'));
      const data = await response.json();
      console.log('Timetables response:', data);
      if (data.timetables) {
        console.log('Setting timetables:', data.timetables);
        setTimetables(data.timetables);
        setSelectedTimetable('');
        setErrorMessage('');
      } else {
        console.log('No timetables in response:', data);
        setErrorMessage('No timetables generated. Check the input data.');
      }
    } catch (error) {
      console.error('Error generating timetables:', error);
      setErrorMessage('Failed to generate timetables. Please try again.');
    }
  };

  // Define time slots from 8 AM to 6 PM
  const timeSlots = [];
  for (let hour = 8; hour < 18; hour++) {
    timeSlots.push(`${hour}-${hour + 1}`);
  }

  const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];

  // Function to find lecture for a specific time slot and day
  const getLectureForSlot = (timetable, day, startHour) => {
    const slot = timetable.find(
      (entry) =>
        entry.day === day &&
        entry.start_hour <= startHour &&
        entry.end_hour > startHour
    );
    return slot ? `${slot.subject}, ${slot.venue}` : '';
  };

  return (
    <div className="container">
      <h1>Timetable Generator</h1>

      {errorMessage && (
        <div className="error-message" style={{ color: 'red', marginBottom: '10px' }}>
          {errorMessage}
        </div>
      )}

      <form onSubmit={handleFileUpload}>
        <input
          type="file"
          accept=".xlsx"
          onChange={handleFileChange}
        />
        <button type="submit" className="btn-blue">Upload</button>
      </form>

      <div>
        <select
          className="select"
          value={selectedSubject}
          onChange={(e) => setSelectedSubject(e.target.value)}
        >
          <option value="">Select Subject</option>
          {subjectTeacherPairs.map((subject, index) => (
            <option key={index} value={subject}>{subject}</option>
          ))}
        </select>
        <input
          type="number"
          placeholder="Hours per week"
          value={hours}
          onChange={(e) => setHours(e.target.value)}
        />
        <select
          className="select"
          value={year}
          onChange={(e) => setYear(e.target.value)}
        >
          <option value="1st Year">1st Year</option>
          <option value="2nd Year">2nd Year</option>
          <option value="3rd Year">3rd Year</option>
          <option value="4th Year">4th Year</option>
        </select>
        <select
          className="select"
          value={scheduleType}
          onChange={(e) => setScheduleType(e.target.value)}
        >
          <option value="distributed">Distributed Across Days</option>
          <option value="all_together">All Together</option>
        </select>
        <button className="btn-blue" onClick={handleAddSubject}>Add Subject</button>
      </div>

      <div>
        <h2>Selected Subjects</h2>
        <ul>
          {subjectsList.map((subject, index) => (
            <li key={index}>
              {subject.subject_teacher} - {subject.hours} hours - {subject.year} - {subject.schedule_type}
            </li>
          ))}
        </ul>
      </div>

      <button className="btn-green" onClick={handleGenerateTimetables}>
        Generate Timetables
      </button>

      {timetables.length > 0 && (
        <div>
          <h2>Generated Timetables</h2>
          <select
            className="select"
            value={selectedTimetable}
            onChange={(e) => setSelectedTimetable(e.target.value)}
          >
            <option value="">Select Timetable</option>
            {timetables.map((_, index) => (
              <option key={index} value={index}>Timetable {index + 1}</option>
            ))}
          </select>

          {selectedTimetable !== '' && (
            <table className="table">
              <thead>
                <tr>
                  <th>Time</th>
                  {days.map((day) => (
                    <th key={day}>{day}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {timeSlots.map((slot, index) => {
                  const startHour = parseInt(slot.split('-')[0]);
                  return (
                    <tr key={index}>
                      <td>{slot}</td>
                      {days.map((day) => (
                        <td key={day}>
                          {getLectureForSlot(timetables[selectedTimetable], day, startHour)}
                        </td>
                      ))}
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}
        </div>
      )}
    </div>
  );
}

export default App;